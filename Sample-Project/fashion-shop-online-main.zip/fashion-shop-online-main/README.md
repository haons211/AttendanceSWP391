# Group 5

# Fashion Shop

# KingsMan - Giải pháp mua sắm tủ đồ cho nam giới

## Video demo

- View it here : https://www.youtube.com/watch?v=eW4Oz8bCDp8

#### Teams
- Nguyễn Trí Trường Sơn - Leader
- Nguyễn Hữu Minh Đức
- Đỗ Trung Khang
- Bùi Văn Hải
- Nghiêm Đức Độ
